<?php 
Class Locacao{
    private $veiculoPlaca;
    private $clienteCpf;
    private $dataLocacao;
    private $dataDevolucao;
    private $conexao;

    public function __construct($veiculoPlaca, $clienteCpf, $dataLocacao, $dataDevolucao, $conexao)
    {
        $this->veiculoPlaca = $veiculoPlaca;
        $this->clienteCpf = $clienteCpf;
        $this->dataLocacao = $dataLocacao;
        $this->dataDevolucao = $dataDevolucao;
        $this->conexao = $conexao;
    }


    public function listarLocacoes(){
        $sql = "SELECT 
    tblocacao.locacao_codigo, 
    tblocacao.locacao_veiculo, 
    tblocacao.locacao_cliente, 
    tblocacao.locacao_data_inicio, 
    tblocacao.locacao_data_fim,
    tbveiculo.veiculo_descricao, 
    tbcliente.cliente_nome, 
    tbmarca.marca_descricao
    FROM 
        tblocacao
    INNER JOIN tbveiculo 
        ON tblocacao.locacao_veiculo = tbveiculo.veiculo_placa
    INNER JOIN tbcliente 
        ON tblocacao.locacao_cliente = tbcliente.cliente_cpf
    INNER JOIN tbmarca 
        ON tbveiculo.veiculo_marca = tbmarca.marca_codigo;";
        $resultado = $this->conexao->query($sql);
    if ($resultado->num_rows>0) {
        $loc_codigo = $row['locacao_codigo'];
        $loc_veiculo_placa = $row['locacao_veiculo'];
        $loc_cliente_cpf = $row['locacao_cliente'];
        $loc_dt_inicio = $row['locacao_data_inicio'];
        $loc_dt_fim = $row['locacao_data_fim'];
        $
        $
        $

        echo "listagem de locações<br><table>";





    }



    } 

    // public function inserirLocacao(){
    //     $sql = "INSERT INTO tblocacao(veiculo_placa, cliente_cpf, data_locacao, data_devolucao) VALUES (?,?,?,?)";
    //     $stmt = $this->conexao->prepare($sql);
    //     $stmt->bind_param('ssss', $this->veiculoPlaca, $this->clienteCpf, $this->dataLocacao, $this->dataDevolucao);
    //     if($stmt->execute()){
    //         echo "locação inserida com sucesso!";
    //     }else{
    //         echo "erro ao inserir locação: ". $stmt->error;
    //     }
    // }
}




?>